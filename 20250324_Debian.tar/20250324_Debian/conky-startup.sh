#!/bin/sh

# Define conky directory path
CONKY_DIR="$HOME/.conky/MyConky"

if [ "$DESKTOP_SESSION" = "debian" ]
then
    # Kill any existing conky processes
    pkill conky

    # Wait for desktop to settle
    sleep 20s

    # Start conky configurations
    conky -c "$CONKY_DIR/.conkyrc_system" &
    conky -c "$CONKY_DIR/.conkyrc_time" &
    conky -c "$CONKY_DIR/.conkyrc_shortcuts" &
fi
