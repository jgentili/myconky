#!/bin/sh

if "$DESKTOP_SESSION" = "budgie-desktop"; then 
   sleep 20s
   killall conky
   cd "$HOME/.conky/Solus-Conky"
   conky -c "$HOME/.conky/Solus-Conky/conkyrc_shortcuts" &
   cd "$HOME/.conky/Solus-Conky"
   conky -c "$HOME/.conky/Solus-Conky/conkyrc_system" &
   cd "$HOME/.conky/Solus-Conky"
   conky -c "$HOME/.conky/Solus-Conky/conkyrc_time" &
   exit 0
fi
