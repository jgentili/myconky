#! /bin/bash
sleep 15 &&
exec conky --config=$HOME/.conky/MyConky/.conkyrc_system &
exec conky --config=$HOME/.conky/MyConky/.conkyrc_time &
## exec conky --config=$HOME/.conky/MyConky/.conkyrc_weather &
exec conky --config=$HOME/.conky/MyConky/.conkyrc_shortcuts &
